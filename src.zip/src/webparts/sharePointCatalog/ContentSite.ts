import {ISPList} from './SharePointCatalogWebPart';
import * as $ from 'jquery';

export default class ContentSite
{
    private  _absoluteUrl:String;
    private  _items = new Array();
    ContentSite(){}
    public getContent(){
        console.log('getcontent');
        var array = new Array();
        $.ajax({
            url: this._absoluteUrl+ `/_api/web/lists?$filter=Hidden eq false`,
            method: "GET",
            headers: { "Accept": "application/json; odata=verbose" },
            success: function (data) {
                 
                 //var _item:ISPList;
                 if (data.d.results.length > 0 ) {
                    
                   data.d.results.forEach(element => {

                     array.push({Title:element.Title,Id:element.Id});
                   });
                   console.log(array);
                   return array; 
                 }
                    
           },
           error: function (data) {
               alert("Error: "+ data);
          }
          
        });
        return array;
    }

    public setUrl(urlSP){
        this._absoluteUrl = urlSP;
    }

    public get2(){
        return this._items;
    }
}