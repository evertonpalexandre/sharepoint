import {ISPList} from './SharePointCatalogWebPart';

export default class MockHttpClient
{
    private static _items: ISPList[] = [{Title: "Mock List 1 tst",Id:'1'},
                                        {Title: "Mock List 2",Id:'2'},
                                        {Title: "Mock List 3",Id:'3'}];


    public static get(){
        return MockHttpClient._items;
    }
}