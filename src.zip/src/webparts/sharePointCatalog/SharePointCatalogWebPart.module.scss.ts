/* tslint:disable */
require('./SharePointCatalogWebPart.module.css');
const styles = {
  sharePointCatalog: 'sharePointCatalog_efd3992a',
  list_: 'list__efd3992a',
  listItem: 'listItem_efd3992a',
  container: 'container_efd3992a',
  row: 'row_efd3992a',
  column: 'column_efd3992a',
  'ms-Grid': 'ms-Grid_efd3992a',
  title: 'title_efd3992a',
  subTitle: 'subTitle_efd3992a',
  description: 'description_efd3992a',
  button: 'button_efd3992a',
  label: 'label_efd3992a',
};

export default styles;
/* tslint:enable */