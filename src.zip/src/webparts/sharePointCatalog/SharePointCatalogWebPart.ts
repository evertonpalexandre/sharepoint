import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField,
  PropertyPaneCheckbox,
  PropertyPaneDropdown,
  PropertyPaneToggle
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './SharePointCatalogWebPart.module.scss';
import * as strings from 'SharePointCatalogWebPartStrings';
import MockHttpClient from './MockHttpClient';
import ContentSite from './ContentSite';
import {
  SPHttpClient,
  SPHttpClientResponse   
 } from '@microsoft/sp-http';
 import {
  Environment,
  EnvironmentType
 } from '@microsoft/sp-core-library';
 import * as $ from 'jquery';

 

export interface ISharePointCatalogWebPartProps {
  listUrl: string;
  ascending: boolean;
  view: string;
  fields: string;

}

export interface ISPLists {
  value: ISPList[];
 }
 
 export interface ISPList {
  Title: string;
  Id: string;
 }



export default class SharePointCatalogWebPart extends BaseClientSideWebPart<ISharePointCatalogWebPartProps> {
  private array = new Array();
  public render(): void {

    
    var _content = new ContentSite();
    
   _content.setUrl(this.context.pageContext.web.absoluteUrl);
   ;
   this.array = _content.getContent();
   
    this.domElement.innerHTML = `
     <div class="${ styles.sharePointCatalog }">
       <div class="${ styles.container }">
         <div class="${ styles.row }">
           <div class="${ styles.column }">
             <span class="${ styles.title }">Welcome to SharePoint!</span>
             <p class="${ styles.subTitle }">Customize SharePoint experiences using web parts.</p>
             <p class="${ styles.description }">${escape(this.properties.listUrl)}</p>
             <p class="${ styles.description }">Loading from ${escape(this.context.pageContext.web.title)}</p>
             <a href="https://aka.ms/spfx" class="${ styles.button }">
               <span class="${ styles.label }">Learn more</span>
             </a>
           </div>
         </div>
         <div id="spListContainer" />
       </div>
     </div>`;

     this._renderListAsync();
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  private _getMockListData() {
    return MockHttpClient.get();
  }

  //private _getContentSite() {
  //  var arrayTst = new Array();
  //  ContentSite.setUrl(this.context.pageContext.web.absoluteUrl);
  //  arrayTst = ContentSite.get();

  //  return arrayTst;
  //}

 

  private _renderListAsync(): void {
    // Local environment
    if (Environment.type === EnvironmentType.Local) {
        this._renderList(this._getMockListData());
    }
    else if (Environment.type == EnvironmentType.SharePoint || 
              Environment.type == EnvironmentType.ClassicSharePoint) {
                
                this._renderList(this.array);
    }
  }

  private _renderList(items): void {
    console.log('entrou renderlist')
    let html: string = '';
    items.forEach((item) => {
      html += `
    <ul class="${styles.list_}">
      <li class="${styles.listItem}">
        <span class="ms-font-l">${item.Title}</span>
      </li>
    </ul>`;
    });
 
    const listContainer: Element = this.domElement.querySelector('#spListContainer');
    listContainer.innerHTML = html;
  }


  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('listUrl', {
                  label: 'listUrl'
                }),
                PropertyPaneToggle('ascending', {
                  label: 'Ascendente',
                  onText: 'On',
                  offText: 'Off'
                }),
                PropertyPaneTextField('view', {
                  label: 'View'
                }),
                PropertyPaneTextField('fields', {
                  label: 'fields'
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
