declare interface ISharePointCatalogWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SharePointCatalogWebPartStrings' {
  const strings: ISharePointCatalogWebPartStrings;
  export = strings;
}
